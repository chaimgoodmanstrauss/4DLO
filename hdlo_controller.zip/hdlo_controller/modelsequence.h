////////////////////////////////////
//
//   modelsequence.h
//
// Sequence management system for HDLO controller
//
#ifndef MODELSEQUENCE_H
#define MODELSEQUENCE_H

#include "models.h"
#include <array>
#include <vector>

// Audio source configuration
struct AudioSourceConfig {
    enum SourceType { MICROPHONE, SD_CARD, LINE_IN };
    SourceType type;
    String filename;  // For SD_CARD type
    bool loop;        // For SD_CARD type
    
    AudioSourceConfig() : type(MICROPHONE), filename(""), loop(false) {}
    AudioSourceConfig(SourceType t, String fn = "", bool l = false) 
        : type(t), filename(fn), loop(l) {}
};

// Transition types
enum TransitionType {
    INSTANT,
    FADE,
    WIPE
};

// Function with palette specification
struct FunctionWithPalette {
    String functionName;
    String paletteName;
    std::vector<FunctionParameter> parameters;
    
    FunctionWithPalette() : functionName("dark"), paletteName("") {}
    
    FunctionWithPalette(String fn, String pn = "")
        : functionName(fn), paletteName(pn), parameters() {}
    
    FunctionWithPalette(String fn, String pn, std::initializer_list<float> params)
        : functionName(fn), paletteName(pn) {
        for(float p : params) {
            parameters.push_back(FunctionParameter(p));
        }
    }
};

// Sequence step structure
struct SequenceStep {
    colormodel* model;
    std::array<FunctionWithPalette, 4> functions;
    unsigned long duration;
    TransitionType transitionType;
    unsigned long transitionDuration;
    AudioSourceConfig audioConfig;
    
    SequenceStep()
        : model(nullptr),
          duration(5000),
          transitionType(INSTANT),
          transitionDuration(0) {}
    
    SequenceStep(colormodel* m,
                 const std::array<FunctionWithPalette, 4>& funcs,
                 unsigned long dur,
                 TransitionType trans = INSTANT,
                 unsigned long transDur = 0,
                 AudioSourceConfig audio = AudioSourceConfig())
        : model(m),
          functions(funcs),
          duration(dur),
          transitionType(trans),
          transitionDuration(transDur),
          audioConfig(audio) {}
};

// Sequence registry entry
struct SequenceRegistryEntry {
    int startStepIndex;
    int numSteps;
    String name;
    unsigned long duration;
    bool enabled;
    
    SequenceRegistryEntry()
        : startStepIndex(0), numSteps(0), name(""), duration(60000), enabled(false) {}
    
    SequenceRegistryEntry(int start, int count, String n, unsigned long dur, bool en = true)
        : startStepIndex(start), numSteps(count), name(n), duration(dur), enabled(en) {}
};

// Main sequence class
class modelsequence {
private:
    static const int MAX_STEPS = 100;
    static const int MAX_REGISTRY_ENTRIES = 20;
    
    SequenceStep steps[MAX_STEPS];
    int numSteps;
    int currentStep;
    unsigned long stepStartTime;
    
    SequenceRegistryEntry registry[MAX_REGISTRY_ENTRIES];
    int numRegistryEntries;
    int currentRegistryIndex;
    unsigned long registryStartTime;
    
    bool inTransition;
    unsigned long transitionStartTime;
    float transitionProgress;
    
    void applyFunctionsToModel();
    void configureAudioSource(const AudioSourceConfig& config);
    
public:
    modelsequence();
    
    // Step management
    void addStep(const SequenceStep& step);
    void clearSteps();
    
    // Registry management
    void beginRegistry(String name, unsigned long duration = 60000, bool enabled = true);
    void endRegistry();
    int getNumRegistryEntries() const { return numRegistryEntries; }
    String getCurrentRegistryName() const;
    
    // Playback control
    void update();
    colormodel* getCurrentModel();
    CRGB getColor(int edgeindex, float position);
    
    // Status
    int getCurrentStep() const;
    float getProgress() const;
    bool isInTransition() const { return inTransition; }
    float getTransitionProgress() const { return transitionProgress; }
    
    void reset();
    void printSequenceInfo();
};

/////////////////////////////////////////
// SEQUENCE BUILDER HELPER
//
// Allows clean syntax like:
// seq.add("test", {{"plasma","ocean",2.0}, {"fire2012","fire"}}, 10000);
//
struct SequenceBuilder {
    modelsequence* seq;
    
    SequenceBuilder(modelsequence* s) : seq(s) {}
    
    // Add step with clean nested initializer syntax
    void add(String modelName,
             std::initializer_list<std::initializer_list<String>> funcDefs,
             unsigned long duration) {
        
        colormodel* model = colormodel::findModelByName(modelName);
        if(!model) {
            Serial.println("Error: Model '" + modelName + "' not found");
            return;
        }
        
        std::array<FunctionWithPalette, 4> functions;
        int idx = 0;
        
        for(auto def : funcDefs) {
            if(idx >= 4) break;
            
            auto it = def.begin();
            String funcName = (it != def.end()) ? *it++ : "dark";
            String palette = (it != def.end()) ? *it++ : "";
            
            // Collect remaining params as floats (convert from String)
            std::vector<float> params;
            while(it != def.end()) {
                params.push_back((*it++).toFloat());
            }
            
            if(params.empty()) {
                functions[idx] = FunctionWithPalette(funcName, palette);
            } else {
                // Build initializer_list by explicitly listing params
                switch(params.size()) {
                    case 1:
                        functions[idx] = FunctionWithPalette(funcName, palette, {params[0]});
                        break;
                    case 2:
                        functions[idx] = FunctionWithPalette(funcName, palette, {params[0], params[1]});
                        break;
                    case 3:
                        functions[idx] = FunctionWithPalette(funcName, palette, {params[0], params[1], params[2]});
                        break;
                    case 4:
                        functions[idx] = FunctionWithPalette(funcName, palette, {params[0], params[1], params[2], params[3]});
                        break;
                    default:
                        // Fallback - just use first 4
                        functions[idx] = FunctionWithPalette(funcName, palette, {params[0]});
                        break;
                }
            }
            idx++;
        }
        
        // Fill remaining slots with dark
        while(idx < 4) {
            functions[idx++] = FunctionWithPalette("dark", "");
        }
        
        seq->addStep(SequenceStep(model, functions, duration));
    }
};

#endif // MODELSEQUENCE_H
