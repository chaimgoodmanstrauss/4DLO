////////////////////////////////////
//
//   sequences.cpp
//
// Sequence definitions using new architecture
// Examples of how to create sequences with the refactored system
//

#include "modelsequence.h"
#include "hdlo_models.h"

// Global sequence object
modelsequence mainSequence;

void initializeSequences() {
    Serial.println("Initializing sequences...");
    
    // Get models from registry
    colormodel* testModel = colormodel::findModelByName("test");
    
    if(!testModel) {
        Serial.println("ERROR: test model not found!");
        return;
    }
    
    // Create builder for clean syntax
    SequenceBuilder seq(&mainSequence);
    
    /////////////////////////////////////////
    // SEQUENCE 1: Plasma showcase
    /////////////////////////////////////////
    mainSequence.beginRegistry("Plasma Showcase", 30000, true);
    
    // Step 1: All plasma with different palettes - clean nested syntax
    seq.add("test", {
        {"plasma", "ocean"},
        {"plasma", "fire"},
        {"plasma", "rainbow"},
        {"plasma", "lava"}
    }, 10000);
    
    // Step 2: Plasma with speed parameters
    seq.add("test", {
        {"plasma", "ocean", "2.0"},
        {"plasma", "fire", "0.5"},
        {"plasma", "rainbow", "1.0"},
        {"plasma", "lava", "1.5"}
    }, 10000);
    
    mainSequence.endRegistry();
    
    // Start the sequence
    mainSequence.reset();
    
    Serial.println("Sequences initialized!");
    mainSequence.printSequenceInfo();
}

// Call this from loop()
void updateSequence() {
    mainSequence.update();
}

// Get color for rendering
CRGB getSequenceColor(int edgeindex, float position) {
    return mainSequence.getColor(edgeindex, position);
}
